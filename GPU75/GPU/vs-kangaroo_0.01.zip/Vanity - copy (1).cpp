/*
 * This file is part of the VanitySearch distribution (https://github.com/JeanLucPons/VanitySearch).
 * Copyright (c) 2019 Jean Luc PONS.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
*/

#include "Vanity.h"
#include "Base58.h"

#include "hash/sha256.h"
#include "hash/sha512.h"
#include "IntGroup.h"

#include "Timer.h"
#include "hash/ripemd160.h"
#include <string.h>
#include <math.h>
#include <algorithm>
#ifndef WIN64
#include <pthread.h>
#endif

#include "default_pubkeys.h"

using namespace std;

Point	Sp[256];
Int		dS[256];

Point Gn[5], _2Gn;


// ----------------------------------------------------------------------------

VanitySearch::VanitySearch(Secp256K1 *secp, Point targetPubkey, structW *stR, bool useGpu, string outputFile){

  this->secp = secp;
  this->targetPubkey = targetPubkey;
  this->useGpu = useGpu;
  this->outputFile = outputFile;

  this->nbGPUThread = 0;
  this->searchType = -1;

  this->stR = stR;
  this->bnL = stR->bnL;
  this->bnU = stR->bnU;
  this->bnW = stR->bnW;
  this->pow2L = stR->pow2L;
  this->pow2U = stR->pow2U;
  this->pow2W = stR->pow2W;
  this->bnM = stR->bnM;
  this->bnWsqrt = stR->bnWsqrt;
  this->pow2Wsqrt = stR->pow2Wsqrt;

  printf("[rangeW]	2^%u..2^%u ; W = U - L = 2^%u\n"
	  , pow2L, pow2U
	  , pow2W
  );

  int pow2Jmax = 0;

  /////////////////////////////////////////////////
  // discriminator of distinguished points

  DPmodule = (uint64_t)1 << ((pow2W / 2) - 2);
  //printf("[DPmodule]	0x%016llX\n", DPmodule);

  /////////////////////////////////////////////////
  // load default pubkey

  bool targetPubKeyCompressed;
  string pubkeyhex;
  if (targetPubkey.isZero()) {
	  for (int i = 0; i < 33; ++i) { char pub[2+1]; sprintf(pub, "%02hhX", default_pubkeys[pow2U][i]); pubkeyhex += string(pub); }
	  //printf("[pubkeyhex] %s\n", pubkeyhex.c_str());
	  targetPubkey = secp->ParsePublicKeyHex(pubkeyhex, targetPubKeyCompressed);
  }
  printf("[Xcoordinate] 0x%064s\n", targetPubkey.x.GetBase16().c_str());
  printf("[Ycoordinate] 0x%064s\n", targetPubkey.y.GetBase16().c_str());


  /////////////////////////////////////////////////
  // hashtable for distinguished points

  // DPht,DTht,DWht - points, distinguished points of Tp/Wp
  // in hashtable, provides uniqueness distinguished points

  uint64_t maxDP = 1 << 10; // 2^10=1024

  printf("[DPsize]	%llu (hashtable size)\n", maxDP);

  HASH_SIZE = 2 * maxDP;

  DPht = (hashtb_entry *)calloc(HASH_SIZE, sizeof(struct hashtb_entry));

  if (NULL == DPht) {
	  printf("\n[FATAL ERROR] can't alloc mem %.2f %s \n", (float)(HASH_SIZE) * sizeof(struct hashtb_entry)/1024/1024/1024, "GiB");
	  exit(EXIT_FAILURE);
  }


  //exit(1);
  /////////////////////////////////////////////////


}

// ----------------------------------------------------------------------------

bool VanitySearch::isSingularPrefix(std::string pref) {

  // check is the given prefix contains only 1
  bool only1 = true;
  int i=0;
  while (only1 && i < (int)pref.length()) {
    only1 = pref.data()[i] == '1';
    i++;
  }
  return only1;

}


// ----------------------------------------------------------------------------


double log1(double x) {
  // Use taylor series to approximate log(1-x)
  return -x - (x*x)/2.0 - (x*x*x)/3.0 - (x*x*x*x)/4.0;
}

string VanitySearch::GetExpectedTime(double keyRate,double keyCount) {

  char tmp[128];
  string ret;

  double P = 1.0/ _difficulty;
  // pow(1-P,keyCount) is the probality of failure after keyCount tries
  double cP = 1.0 - pow(1-P,keyCount);

  sprintf(tmp,"[P %.2f%%]",cP*100.0);
  ret = string(tmp);
  
  double desiredP = 0.5;
  while(desiredP<cP)
    desiredP += 0.1;
  if(desiredP>=0.99) desiredP = 0.99;
  double k = log(1.0-desiredP)/log(1.0-P);
  if (isinf(k)) {
    // Try taylor
    k = log(1.0 - desiredP)/log1(P);
  }
  double dTime = (k-keyCount)/keyRate; // Time to perform k tries

  if(dTime<0) dTime = 0;

  double nbDay  = dTime / 86400.0;
  if (nbDay >= 1) {

    double nbYear = nbDay/365.0;
    if (nbYear > 1) {
      if(nbYear<5)
        sprintf(tmp, "[%.2f%% in %.1fy]", desiredP*100.0, nbYear);
      else
        sprintf(tmp, "[%.2f%% in %gy]", desiredP*100.0, nbYear);
    }
	else {
      sprintf(tmp, "[%.2f%% in %.1fd]", desiredP*100.0, nbDay);
    }

  }
  else {

    int iTime = (int)dTime;
    int nbHour = (int)((iTime % 86400) / 3600);
    int nbMin = (int)(((iTime % 86400) % 3600) / 60);
    int nbSec = (int)(iTime % 60);

    sprintf(tmp, "[%.2f%% in %02d:%02d:%02d]", desiredP*100.0, nbHour, nbMin, nbSec);

  }

  return ret + string(tmp);

}

// ----------------------------------------------------------------------------

void VanitySearch::output(string addr,string pAddr,string pAddrHex) {

#ifdef WIN64
   WaitForSingleObject(ghMutex,INFINITE);
#else
  pthread_mutex_lock(&ghMutex);
#endif
  
  FILE *f = stdout;
  bool needToClose = false;

  if (outputFile.length() > 0) {
    f = fopen(outputFile.c_str(), "a");
    if (f == NULL) {
      printf("Cannot open %s for writing\n", outputFile.c_str());
      f = stdout;
    } 
	else {
      needToClose = true;
    }
  }

  fprintf(f, "\nPub Addr: %s\n", addr.c_str());

  if (1) {

    switch (searchType) {
    case P2PKH:
      fprintf(f, "Priv (WIF): p2pkh:%s\n", pAddr.c_str());
      break;
     }
    fprintf(f, "Priv (HEX): 0x%064s\n", pAddrHex.c_str());

  }

  if(needToClose)
    fclose(f);

#ifdef WIN64
  ReleaseMutex(ghMutex);
#else
  pthread_mutex_unlock(&ghMutex);
#endif

}


// ----------------------------------------------------------------------------

bool VanitySearch::checkPrivKey(string addr, Int &key, int32_t incr, int endomorphism, bool mode) {

  Int k(&key);
  Point sp = targetPubkey;

  if (incr < 0) {
    k.Add((uint64_t)(-incr));
    k.Neg();
    k.Add(&secp->order);
  } 
  else {
    k.Add((uint64_t)incr);
  }


  // Check addresses
  Point p = secp->ComputePublicKey(&k);

  string chkAddr = secp->GetAddress(searchType, mode, p);
  if (chkAddr != addr) {

    //Key may be the opposite one (negative zero or compressed key)
    k.Neg();
    k.Add(&secp->order);
    p = secp->ComputePublicKey(&k);

	string chkAddr = secp->GetAddress(searchType, mode, p);
    if (chkAddr != addr) {
      printf("\nWarning, wrong private key generated !\n");
      printf("  Addr :%s\n", addr.c_str());
      printf("  Check:%s\n", chkAddr.c_str());
      printf("  Endo:%d incr:%d comp:%d\n", endomorphism, incr, mode);
      return false;
    }

  }

  output(addr, secp->GetPrivAddress(mode ,k), k.GetBase16());

  return true;

}


// ----------------------------------------------------------------------------

#ifdef WIN64
DWORD WINAPI _FindKey(LPVOID lpParam) {
#else
void *_FindKey(void *lpParam) {
#endif
  TH_PARAM *p = (TH_PARAM *)lpParam;
  p->obj->FindKeyCPU(p);
  return 0;
}

#ifdef WIN64
DWORD WINAPI _FindKeyGPU(LPVOID lpParam) {
#else
void *_FindKeyGPU(void *lpParam) {
#endif
  TH_PARAM *p = (TH_PARAM *)lpParam;
  p->obj->FindKeyGPU(p);
  return 0;
}

// ----------------------------------------------------------------------------



void VanitySearch::FindKeyCPU(TH_PARAM *ph) {

  int thId = ph->threadId;

  if (VERBOSE_LEVEL > 0)
	  printf("[th][%s#%d] run.. \n", (ph->type ? "wild" : "tame"), (ph->type ? thId+1-xU : thId+1));


  countj[thId] = 0;
  ph->hasStarted = true;


  while (!flag_endOfSearch) {

	  countj[thId] += 1;

	  uint64_t Xn0 = ph->Kp.x.bits64[0];
	  uint64_t pw = Xn0 % JmaxofSp;

	  //nowjumpsize = 1 << pw
	  Int nowjumpsize = dS[pw];

	  // check, is it distinguished point ?
	  if (Xn0 % DPmodule == 0) {

		  // send new distinguished point to parent
		  #ifdef WIN64
		  WaitForSingleObject(ghMutex, INFINITE);
		  #else
		  pthread_mutex_lock(&ghMutex);
		  #endif
		  bool flag_newDP = true;

		  uint64_t entry = Xn0 & (HASH_SIZE-1);
		  while (DPht[entry].n0 != 0) {

			  if (DPht[entry].n0 == Xn0
				  //&& DPht[entry].n1 == ph->Kp.x.bits64[1]
				  //&& DPht[entry].n2 == ph->Kp.x.bits64[2]
				  //&& DPht[entry].n3 == ph->Kp.x.bits64[3]
				  ) {

				  if (DPht[entry].type != ph->type) {

					  flag_endOfSearch = true;

					  if (ph->dK.IsLower(&DPht[entry].distance)) {
						  //result_prvkey.Sub(&DPht[entry].distance, &dK);
					  }
					  else if (ph->dK.IsGreater(&DPht[entry].distance)) {
						  //result_prvkey.Sub(&dK, &DPht[entry].distance);
					  }
					  else {
						  printf("\n[FATAL_ERROR] dT == dW !!!\n");
						  exit(EXIT_FAILURE);
					  }

				  }
				  else {

					  flag_newDP = false;

					  // generate random even offset
					  uint32_t pow2offset = (uint64_t)rndl() % JmaxofSp;
						  
					  if (pow2offset == 0) {
						  ph->dK.AddOne();
						  ph->Kp = secp->AddAffine( ph->Kp, Sp[0] );
					  }
					  else {
						  Int Ktmp;
						  Ktmp.ShiftL(pow2offset);
						  ph->dK.Add(&Ktmp);
						  ph->dK.AddOne();
						  ph->Kp = secp->AddAffine( secp->AddAffine(ph->Kp, Sp[pow2offset]), Sp[0] );
					  }
						  
					  if (VERBOSE_LEVEL > 0) {
						  printf("[th][%s#%d] repair#*/*: 0x%064s\n"
							  , (ph->type ? "wild" : "tame")
							  , (ph->type ? thId + 1 - xU : thId + 1)
							  , ph->Kp.x.GetBase16().c_str()
						  );

					  }

				  }

				  //printf("[X] 0x%064s\n", ph->Kp.x.GetBase16().c_str());

				  break;
			  }
			  //++n_coll; // useless collision
			  entry = (entry + (ph->Kp.x.bits64[1] | 1)) & (HASH_SIZE-1);
		  }
		  //if (flag_endOfSearch) break;

		  if (flag_newDP) {
			  DPht[entry].distance = ph->dK;
			  DPht[entry].n0 = Xn0;
			  //DPht[entry].n1 = ST.n[1];
			  //DPht[entry].n2 = ST.n[2];
			  //DPht[entry].n3 = ST.n[3];
			  DPht[entry].type = ph->type;
		  }

		  #ifdef WIN64
		  ReleaseMutex(ghMutex);
		  #else
		  pthread_mutex_unlock(&ghMutex);
		  #endif
	  }
	  //if (flag_endOfSearch) break;

	  ph->dK.Add(&nowjumpsize);
	  ph->Kp = secp->AddAffine(ph->Kp, Sp[pw]);


  }

  ph->isRunning = false;

}

// ----------------------------------------------------------------------------

void VanitySearch::getGPUStartingKeys(int thId, int groupSize, int nbThread, Int *keys, Point *p) {

  for (int i = 0; i < nbThread; i++) {

      keys[i].Set(&targetPubkey.x);
      Int offT((uint64_t)i);
      offT.ShiftL(80);
      Int offG((uint64_t)thId);
      offG.ShiftL(112);
      keys[i].Add(&offT);
      keys[i].Add(&offG);

    Int k(keys + i);
    // Starting key is at the middle of the group
    k.Add((uint64_t)(groupSize / 2));
    p[i] = secp->ComputePublicKey(&k);

  }

}

void VanitySearch::FindKeyGPU(TH_PARAM *ph) {

  bool ok = true;

#ifdef WITHGPU

  // Global init
  int thId = ph->threadId;
  GPUEngine g(ph->gridSize, ph->gpuId);
  int nbThread = g.GetNbThread();
  Point *p = new Point[nbThread];
  Int *keys = new Int[nbThread];
  vector<ITEM> found;

  printf("GPU: %s\n",g.deviceName.c_str());

  countj[thId] = 0;

  getGPUStartingKeys(thId, g.GetGroupSize(), nbThread, keys, p);

  g.SetSearchType(searchType);
  if (1) {
    g.SetPubkey(targetPubkey);
  }

  getGPUStartingKeys(thId, g.GetGroupSize(), nbThread, keys, p);
  ok = g.SetKeys(p);


  ph->hasStarted = true;

  // GPU Thread
  while (ok && !flag_endOfSearch) {


    // Call kernel
    ok = g.Launch(found);

    for(int i=0;i<(int)found.size() && !flag_endOfSearch;i++) {

      ITEM it = found[i];
      //checkAddr(*(prefix_t *)(it.hash), it.hash, keys[it.thId], it.incr, it.endo, it.mode);
 
    }

    if (ok) {
      for (int i = 0; i < nbThread; i++) {
        keys[i].Add((uint64_t)STEP_SIZE);
      }
	  countj[thId] += 1 * STEP_SIZE * nbThread; // Point only
    }

  }

  delete[] keys;
  delete[] p;

#else
  ph->hasStarted = true;
  printf("GPU code not compiled, use -DWITHGPU when compiling.\n");
#endif

  ph->isRunning = false;

}

// ----------------------------------------------------------------------------

bool VanitySearch::isAlive(TH_PARAM *p) {

  bool isAlive = true;
  int total = nbCPUThread + nbGPUThread;
  for(int i=0;i<total;i++)
    isAlive = isAlive && p[i].isRunning;

  return isAlive;

}

// ----------------------------------------------------------------------------

bool VanitySearch::hasStarted(TH_PARAM *p) {

  bool hasStarted = true;
  int total = nbCPUThread + nbGPUThread;
  for (int i = 0; i < total; i++)
    hasStarted = hasStarted && p[i].hasStarted;

  return hasStarted;

}


// ----------------------------------------------------------------------------

uint64_t VanitySearch::getGPUCount() {

  uint64_t count = 0;
  for(int i=0;i<nbGPUThread;i++)
    count += countj[0x80L+i];
  return count;

}

uint64_t VanitySearch::getCPUCount() {

  uint64_t count = 0;
  for(int i=0;i<nbCPUThread;i++)
    count += countj[i];
  return count;

}

// ----------------------------------------------------------------------------

uint64_t VanitySearch::getJmaxofSp(Int& optimalmeanjumpsize, Int * dS) {

	if (VERBOSE_LEVEL > 0) {
		printf("[optimal_mean_jumpsize] %s \n", optimalmeanjumpsize.GetBase10().c_str());
	}

	Int sumjumpsize; 
	sumjumpsize.SetInt32(0);

	Int now_meanjumpsize, next_meanjumpsize;
	Int Isub1, Isub2;

	Int Ii;
	for (int i = 1; i < 256; ++i) {

		Ii.SetInt32(i);

		//sumjumpsize  = (2**i)-1
		//sumjumpsize += 2**(i-1)
		//sumjumpsize += dS[i-1]
		sumjumpsize.Add(&dS[i-1]);

		//now_meanjumpsize = int(round(1.0*(sumjumpsize) / (i)));
		now_meanjumpsize = sumjumpsize; now_meanjumpsize.Div(&Ii);

		//next_meanjumpsize = int(round(1.0*(sumjumpsize + 2**i) / (i+1)));
		//next_meanjumpsize = int(round(1.0*(sumjumpsize + dS[i]) / (i+1)));
		next_meanjumpsize = sumjumpsize; next_meanjumpsize.Add(&dS[i]); 
		Ii.SetInt32(i+1); next_meanjumpsize.Div(&Ii); Ii.SetInt32(i);

		//if  optimalmeanjumpsize - now_meanjumpsize <= next_meanjumpsize - optimalmeanjumpsize : 
		Isub1.Sub(&optimalmeanjumpsize, &now_meanjumpsize);
		Isub2.Sub(&next_meanjumpsize, &optimalmeanjumpsize);

		if (VERBOSE_LEVEL > 1)
			printf("[meanjumpsize#Sp[%d]] %s(now) <= %s(optimal) <= %s(next)\n", i
				, now_meanjumpsize.GetBase10().c_str()
				, optimalmeanjumpsize.GetBase10().c_str()
				, next_meanjumpsize.GetBase10().c_str()
			);

		//if (Isub1.IsLowerOrEqual(&Isub2)) invalid compare for signed int!!! only unsigned int correct compared.
		if (
			   ((Isub1.IsNegative() || Isub1.IsZero()) && Isub2.IsPositive())
			|| ( Isub1.IsNegative() && (Isub2.IsZero() || Isub2.IsPositive()))
			|| ((Isub1.IsPositive() || Isub1.IsZero()) && (Isub2.IsPositive() || Isub2.IsZero()) && Isub1.IsLowerOrEqual(&Isub2))
			|| ((Isub1.IsNegative() || Isub1.IsZero()) && (Isub2.IsNegative() || Isub2.IsZero()) && Isub1.IsLowerOrEqual(&Isub2))
		) {

			if (VERBOSE_LEVEL > 0)
				printf("[meanjumpsize#Sp[%d]] %s(now) <= %s(optimal) <= %s(next)\n", i
					, now_meanjumpsize.GetBase10().c_str()
					, optimalmeanjumpsize.GetBase10().c_str()
					, next_meanjumpsize.GetBase10().c_str()
				);

			// location in keyspace on the strip
			if (VERBOSE_LEVEL > 0) {

				//if (optimalmeanjumpsize - now_meanjumpsize) >= 0:
				if (Isub1.IsZero() || Isub1.IsPositive()) {
					//len100perc = 60
					Int len100perc; len100perc.SetInt32(60);
					//size1perc = (next_meanjumpsize-now_meanjumpsize)//len100perc
					Int size1perc; size1perc.Sub(&next_meanjumpsize, &now_meanjumpsize);
					size1perc.Div(&len100perc);
					printf("[i] Sp[%d]|", i);
						//, '-'*(abs(optimalmeanjumpsize - now_meanjumpsize)//size1perc)
					Isub1.Abs(); Isub1.Div(&size1perc);
					for (uint32_t j = 0 ; j < Isub1.GetInt32() ; ++j) printf("-");
					printf("J");
						//, '-'*(abs(next_meanjumpsize - optimalmeanjumpsize)//size1perc)
					Isub2.Abs(); Isub2.Div(&size1perc);
					for (uint32_t j = 0 ; j < Isub2.GetInt32() ; ++j) printf("-");
					printf("|Sp[%d]\n", i+1);
					//if (1.0 * abs(optimalmeanjumpsize - now_meanjumpsize) / abs(next_meanjumpsize - optimalmeanjumpsize) >= 0.25) {
					Isub1.Sub(&optimalmeanjumpsize, &now_meanjumpsize); Isub1.Abs();
					Isub2.Sub(&next_meanjumpsize, &optimalmeanjumpsize); Isub2.Abs();
					if ((float) Isub1.GetInt32() / Isub2.GetInt32() >= 0.25) {
						printf("[i] this Sp set has low efficiency (over -25%%) for this mean jumpsize\n");
					}
				}
				else {
					//now_meanjumpsize = int(round(1.0*(sumjumpsize - dS[i-1]) / (i-1)))
					//next_meanjumpsize = int(round(1.0*(sumjumpsize) / (i)))
					Ii.SetInt32(i-1);
					now_meanjumpsize = sumjumpsize; now_meanjumpsize.Sub(&dS[i-1]); now_meanjumpsize.Div(&Ii);
					Ii.SetInt32(i);
					next_meanjumpsize = sumjumpsize; next_meanjumpsize.Div(&Ii);

					//if  optimalmeanjumpsize - now_meanjumpsize <= next_meanjumpsize - optimalmeanjumpsize : 
					Isub1.Sub(&optimalmeanjumpsize, &now_meanjumpsize);
					Isub2.Sub(&next_meanjumpsize, &optimalmeanjumpsize);

					//len100perc = 60
					Int len100perc; len100perc.SetInt32(60);
					//size1perc = (next_meanjumpsize - now_meanjumpsize)//len100perc
					Int size1perc; size1perc.Sub(&next_meanjumpsize, &now_meanjumpsize);
					size1perc.Div(&len100perc);
					printf("[i] Sp[%d]|", i-1);
					//, '-'*(abs(optimalmeanjumpsize - now_meanjumpsize)//size1perc)
					Isub1.Abs(); Isub1.Div(&size1perc);
					for (uint32_t j = 0; j < Isub1.GetInt32() ; ++j) printf("-");
					printf("J");
					//, '-'*(abs(next_meanjumpsize - optimalmeanjumpsize)//size1perc)
					Isub2.Abs(); Isub2.Div(&size1perc);
					for (uint32_t j = 0; j < Isub2.GetInt32() ; ++j) printf("-");
					printf("|Sp[%d]\n", i);
					//if (1.0 * abs(next_meanjumpsize - optimalmeanjumpsize) / abs(optimalmeanjumpsize - now_meanjumpsize) >= 0.25) {
					Isub1.Sub(&next_meanjumpsize, &optimalmeanjumpsize); Isub1.Abs();
					Isub2.Sub(&optimalmeanjumpsize, &now_meanjumpsize); Isub2.Abs();
					if ((float) Isub1.GetInt32() / Isub2.GetInt32() >= 0.25) {
						printf("[i] this Sp set has low efficiency (over -25%%) for this mean jumpsize\n");
					}
				}
			}

			if (VERBOSE_LEVEL > 0)
				printf("[JmaxofSp] Sp[%d]=%s nearer to optimal mean jumpsize of Sp set\n", i
					, now_meanjumpsize.GetBase10().c_str()
				);

			return i;
		}
	}
	return 0;
}


// ----------------------------------------------------------------------------

void VanitySearch::Search(int nbThread, std::vector<int> gpuId, std::vector<int> gridSize, std::string flag_profile) {

  double t0, t1;

  nbCPUThread = nbThread;
  nbGPUThread = (useGpu?(int)gpuId.size():0);

  flag_endOfSearch = false;
  

  /////////////////////////////////////////////////
  // pre-compute set S(i) jumps of pow2 jumpsize

  Sp[0] = secp->G;
  dS[0].SetInt32(1);
  for (int i = 1; i < 256; ++i) {
	  Sp[i] = secp->DoubleAffine(Sp[i-1]);
	  dS[i].Add(&dS[i-1], &dS[i-1]);
  }
  bool flag_recalcSp = false;

  /////////////////////////////////////////////////
  // profiles load


  // number kangaroos of herd T/W
  if (nbCPUThread == 1 || nbCPUThread == 2) {
	  xU = xV = 1;
	  bxU.SetInt32(xU); bxV.SetInt32(xV); bxUV.Mult(&bxU, &bxV);

  } 
  else if (nbCPUThread >= 4) {

	  if (flag_profile == "byPollard") {
		  // odd int
		  xU = (nbCPUThread / 2) - 1;
		  xV = (nbCPUThread / 2) + 1;
		  bxU.SetInt32(xU); bxV.SetInt32(xV); bxUV.Mult(&bxU, &bxV);

		  for (int k = 0; k < 256; ++k) {
			  if (!flag_recalcSp) Sp[k] = secp->MultKAffine(bxUV, Sp[k]);
		  }
		  flag_recalcSp = true;
		  printf("[+] recalc Sp-table of multiply UV\n");
	  } 
	  else if (flag_profile == "NaiveSplitRange") {
		  xU = xV = nbCPUThread / 2;
		  bxU.SetInt32(xU); bxV.SetInt32(xV); bxUV.Mult(&bxU, &bxV);
	  } 
	  else if (flag_profile == "byOorschot&Wiener") {
		  xU = xV = nbCPUThread / 2;
		  bxU.SetInt32(xU); bxV.SetInt32(xV); bxUV.Mult(&bxU, &bxV);
	  } 
	  else {
		  xU = xV = nbCPUThread / 2;
		  bxU.SetInt32(xU); bxV.SetInt32(xV); bxUV.Mult(&bxU, &bxV);
	  }
  }
  printf("[U]	%d (0x%08x)\n", xU, xU);
  printf("[V]	%d (0x%08x)\n", xV, xV);
  printf("[UV]	%s (0x%064s)\n", bxUV.GetBase10().c_str(), bxUV.GetBase16().c_str());


  Int midJsize;
  midJsize.SetInt32(0);
  //printf("[i] 0x%064s\n", midJsize.GetBase16().c_str());

  // mean jumpsize
  if (xU == 1 && xV == 1) {
	  // by Pollard ".. The best choice of m (mean jump size) is w^(1/2)/2 .."
	  //midJsize = (Wsqrt//2)+1
	  //midJsize = int(round(1.0*Wsqrt / 2))
	  midJsize = bnWsqrt; midJsize.ShiftR(1);
  } 
  else {
	  // expected of 2w^(1/2)/cores jumps
	  if (flag_profile == "byPollard") {
		  //midJsize = int(round(1.0*((1.0*W/(xU*xV))**0.5)/2))
		  //midJsize = int(round(1.0*(xU+xV)*Wsqrt/4));
		  midJsize = bnWsqrt; midJsize.Mult((uint64_t)xU+xV); midJsize.ShiftR(2);
		  //midJsize = int(round(1.0*Wsqrt/2));
	  }
	  // expected of 2(w/cores)^(1/2) jumps
	  else if (flag_profile == "NaiveSplitRange") {
		  //midJsize = int(round(1.0*((1.0*W/xU)**0.5)/2));
		  midJsize = bnW; midJsize.Div(&bxU);
		  Int Itmp; Itmp = midJsize; 
		  int pow2M = 0;
		  for (int i = 0; i < 256; ++i) { Itmp.ShiftR(1); pow2M = i+0; if (Itmp.IsZero()) break; }
		  for (int i = 0; i < pow2M / 2 ; ++i) { midJsize.ShiftR(1); };
		  midJsize.ShiftR(1);
	  }
	  // 
	  else if (flag_profile == "byOorschot&Wiener") {
		  //midJsize = int(round(1.0*(xU + xV)*Wsqrt / 4));
		  midJsize = bnWsqrt; midJsize.Mult((uint64_t)xU + xV); midJsize.ShiftR(2);
		  //midJsize = int(round(1.0*Wsqrt / 2));
	  }
	  // 
	  else {
		  //midJsize = int(round(1.0*Wsqrt / 2))
		  midJsize = bnWsqrt; midJsize.ShiftR(1);
	  }
  }

  JmaxofSp = (uint64_t)getJmaxofSp(midJsize, dS);

  //sizeJmax = 2**JmaxofSp
  sizeJmax = dS[JmaxofSp];


  /////////////////////////////////////////////////
  // create T/W herd

  // dK - int, sum distance traveled
  // Kp - point, sum distance traveled

  TH_PARAM *params = (TH_PARAM *)malloc((nbCPUThread + nbGPUThread) * sizeof(TH_PARAM));
  memset(params, 0, (nbCPUThread + nbGPUThread) * sizeof(TH_PARAM));
  

  Int Ktmp;

  // Tame herd, generate start points
  for (int k = 0; k < xU; ++k) {

	  params[k].type = false; // false - Tame, true - Wild

	  if (xU == 1 && xV == 1) {
		  //dT.append(M)
		  params[k].dK = bnM;
	  }
	  else {
		  if (flag_profile == "byPollard") {
			  //dT.append(M + (k-0)*xV)
			  params[k].dK = bnM;
			  Ktmp.SetInt32(k); Ktmp.Mult(&bxV);
			  params[k].dK.Add(&Ktmp);
		  }
		  else if (flag_profile == "NaiveSplitRange") {
			  //dT.append(L + (W//(2*xU)) + ((k-0)*W//xU) )
			  params[k].dK = bnL;
			  Ktmp.SetInt32(k); Ktmp.Mult(&bnW); Ktmp.Div(&bxU);
			  params[k].dK.Add(&Ktmp);
			  Ktmp = bnW; Ktmp.Div(&bxU); Ktmp.ShiftR(1);
			  params[k].dK.Add(&Ktmp);
		  }
		  else if (flag_profile == "byOorschot&Wiener") {
			  //dT.append(M + (1 << random.randint(1, pow2W-1)) - 1)
			  //dT.append(M + (1 << random.randint(1, pow2W//2))-1 )
			  //dT.append(M + (k+0)*(W//(4*(xU+xV)))-1 )

			  //dT.append(L + (W//(2*xU)) + ((k-0)*W//xU) )
			  params[k].dK = bnL;
			  Ktmp.SetInt32(k); Ktmp.Mult(&bnW); Ktmp.Div(&bxU);
			  params[k].dK.Add(&Ktmp);
			  Ktmp = bnW; Ktmp.Div(&bxU); Ktmp.ShiftR(1);
			  params[k].dK.Add(&Ktmp);
		  }
		  else {
			  //dT.append((3 << (pow2bits-2)) + random.randint(1, (2**(pow2bits-1))))	# by 57fe
			  //dT.append(M + random.randint(1, W))	# by 57fe

			  //dT.append(M + random.randint(1, W//2) )
			  params[k].dK = bnM;
			  Ktmp.Rand(pow2W/2);
			  params[k].dK.Add(&Ktmp);
		  }
	  }

	  // T odd recommended(for more efficiency)
	  if (params[k].dK.IsEven()) {
		  if (flag_profile != "byPollard") {
			  params[k].dK.AddOne();
		  }
	  }

	  if (VERBOSE_LEVEL > 1)	printf("dT[%d] 0x%064s \n", k, params[k].dK.GetBase16().c_str());

	  //Tp.append(mul_ka(dT[k]))
	  printf("\n[i] %064s\n", Ktmp.GetBase16().c_str());exit(1);
	  params[k].Kp = secp->MultKAffine(Ktmp, params[k].Kp);

  }


  // Wild herd, generate start points
  for (int k = xU; k < (xU+xV) ; ++k) {

	  params[k].type = true; // false - Tame, true - Wild

	  if (xU == 1 && xV == 1) {  
		  //dW.append(1)  
		  params[k].dK.SetInt32(1);  
	  }  
	  else { 
		  if (flag_profile == "byPollard") {  
			  //dW.append(1 + xU*(k-0))
			  params[k].dK.SetInt32(1);
			  Ktmp.SetInt32(k); Ktmp.Mult(&bxU);
			  params[k].dK.Add(&Ktmp);
		  }
		  else if (flag_profile == "NaiveSplitRange") {
			  //dW.append(1 + (W//(2*xU)) + ((k-0)*W//xU) )
						  
			  //dW.append(1 + ((k-0)*W//xU) )
			  params[k].dK.SetInt32(1);
			  Ktmp.SetInt32(k); Ktmp.Mult(&bnW); Ktmp.Div(&bxU);
			  params[k].dK.Add(&Ktmp);
		  }
		  else if (flag_profile == "byOorschot&Wiener") {
			  //dW.append((1 << random.randint(1, pow2W-1)) - 1)
			  //dW.append((1 << random.randint(1, pow2W//2))-1 )
			  //dW.append(1 + (k+0)*(1 << (pow2W//(xU+xV)))-1 )
						 
			  //dW.append(1 + ((k-0)*W//xU) )
			  params[k].dK.SetInt32(1);
			  Ktmp.SetInt32(k); Ktmp.Mult(&bnW); Ktmp.Div(&bxU);
			  params[k].dK.Add(&Ktmp);
		  }
		  else {
			  //dW.append(random.randint(1, (1 << (pow2bits-1))))	# by 57fe
			  //dW.append(random.randint(1, W))	# by 57fe
						  
			  //dW.append(random.randint(1, W//2) )
			  params[k].dK.SetInt32(0);
			  Ktmp.Rand(pow2W/2);
			  params[k].dK.Add(&Ktmp);
		  }
	  }

	  // T odd recommended(for more efficiency)
	  if (params[k].dK.IsEven()) {
		  if (flag_profile != "byPollard") {
			  params[k].dK.AddOne();  
		  }
	  }

	  if (VERBOSE_LEVEL > 1)	printf("dW[%d] 0x%064s \n", k, params[k].dK.GetBase16().c_str());

	  //Wp.append(add_a(W0p, mul_ka(dW[k])))
	  params[k].Kp = secp->AddAffine(targetPubkey, secp->MultKAffine(Ktmp, params[k].Kp));

  }

  printf("[+] %dT+%dW herds - ready\n", xU, xV);



  printf("Number of CPU thread: %d\n", nbCPUThread);

  // Launch CPU threads
  // Tame herd, start
  for (int k = 0; k < xU; ++k) {

	  params[k].obj = this;
	  params[k].threadId = k;
	  params[k].isRunning = true;

	  //, DPmodule, JmaxofSp, jump_step
	  //, parent_reciver, send2childs[id_uniq]

#ifdef WIN64
	  DWORD thread_id;
	  CreateThread(NULL, 0, _FindKey, (void*)(params + k), 0, &thread_id);
	  ghMutex = CreateMutex(NULL, FALSE, NULL);
#else
	  pthread_t thread_id;
	  pthread_create(&thread_id, NULL, &_FindKey, (void*)(params + k));
	  ghMutex = PTHREAD_MUTEX_INITIALIZER;
#endif
  }

  // Launch CPU threads
  // Wild herd, start
  for (int k = xU; k < (xU+xV); ++k) {

	  params[k].obj = this;
	  params[k].threadId = k;
	  params[k].isRunning = true;

#ifdef WIN64
	  DWORD thread_id;
	  CreateThread(NULL, 0, _FindKey, (void*)(params + k), 0, &thread_id);
	  ghMutex = CreateMutex(NULL, FALSE, NULL);
#else
	  pthread_t thread_id;
	  pthread_create(&thread_id, NULL, &_FindKey, (void*)(params + k));
	  ghMutex = PTHREAD_MUTEX_INITIALIZER;
#endif
  }


  //Timer::SleepMillis(1000);
  //exit(1);

/*

  // Launch GPU threads
  for (int i = 0; i < nbGPUThread; i++) {
    params[nbCPUThread+i].obj = this;
    params[nbCPUThread+i].threadId = 0x80L+i;
    params[nbCPUThread+i].isRunning = true;
    params[nbCPUThread+i].gpuId = gpuId[i];
    params[nbCPUThread+i].gridSize = gridSize[i];
#ifdef WIN64
    DWORD thread_id;
    CreateThread(NULL, 0, _FindKeyGPU, (void*)(params+(nbCPUThread+i)), 0, &thread_id);
#else
    pthread_t thread_id;
    pthread_create(&thread_id, NULL, &_FindKeyGPU, (void*)(params+(nbCPUThread+i)));  
#endif
  }

*/

#ifndef WIN64
  setvbuf(stdout, NULL, _IONBF, 0);
#endif

  uint64_t lastCount = 0;
  uint64_t gpuCount = 0;
  uint64_t lastGPUCount = 0;

  // Key rate smoothing filter
  #define FILTER_SIZE 8
  double lastkeyRate[FILTER_SIZE];
  double lastGpukeyRate[FILTER_SIZE];
  uint32_t filterPos = 0;

  double keyRate = 0.0;
  double gpuKeyRate = 0.0;

  memset(lastkeyRate, 0, sizeof(lastkeyRate));
  memset(lastGpukeyRate, 0, sizeof(lastGpukeyRate));

  // Wait that all threads have started
  while (!hasStarted(params)) {
    Timer::SleepMillis(500);
  }

  t0 = Timer::get_tick();
  startTime = t0;
  memset(countj, 0, sizeof(countj));

  while (isAlive(params)) {

    int delay = 2000;
    while (isAlive(params) && delay>0) {
      Timer::SleepMillis(500);
      delay -= 500;
    }

    gpuCount = getGPUCount();
    uint64_t count = getCPUCount() + gpuCount;

    t1 = Timer::get_tick();
    keyRate = (double)(count - lastCount) / (t1 - t0);
    gpuKeyRate = (double)(gpuCount - lastGPUCount) / (t1 - t0);
    lastkeyRate[filterPos%FILTER_SIZE] = keyRate;
    lastGpukeyRate[filterPos%FILTER_SIZE] = gpuKeyRate;
    filterPos++;

    // KeyRate smoothing
    double avgKeyRate = 0.0;
    double avgGpuKeyRate = 0.0;
    uint32_t nbSample;
    for (nbSample = 0; (nbSample < FILTER_SIZE) && (nbSample < filterPos); nbSample++) {
      avgKeyRate += lastkeyRate[nbSample];
      avgGpuKeyRate += lastGpukeyRate[nbSample];
    }
    avgKeyRate /= (double)(nbSample);
    avgGpuKeyRate /= (double)(nbSample);

    if (isAlive(params)) {
      printf("%.3f MK/s (GPU %.3f MK/s)  \r"
		  , avgKeyRate/1000000.0, avgGpuKeyRate/1000000.0
	  );
    }


#if 0
	// Check
	{
		bool wrong = false;
		Point p0 = secp.ComputePublicKey(&key);
		for (int i = 0; i < CPU_GRP_SIZE; i++) {
			if (!p0.equals(pts[i])) {
				wrong = true;
				printf("[%d] wrong point\n", i);
			}
			p0 = secp.NextKey(p0);
		}
		if (wrong) exit(0);
	}
#endif

    lastCount = count;
    lastGPUCount = gpuCount;
    t0 = t1;

  }

  free(params);

}
