cat example.dict | ./hashcat64.bin -m 400 example400.hash
